﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConsoleApp2.Data.Models
{
    public class Order_items
    {
        [Key]
        public int order_item_id { get; set; }

        [ForeignKey(nameof(Orders))]
        public int order_id { get; set; }
        Orders orders { get; set; }

        [ForeignKey(nameof(Items))]
        public int item_id { get; set; }
        Items items { get; set; }
        //[ForeignKey(nameof(Items))]


    }

}