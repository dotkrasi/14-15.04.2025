﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConsoleApp2.Data.Models
{
    public class Orders
    {

        [Key]
        public int Id { get; set; }
        
        [ForeignKey(nameof(Orders))]
        public int order_id { get; set; }
        Orders orders { get; set; }

        [ForeignKey(nameof(Customers))]
        public int customer_id { get; set; }
        Customers customers { get; set; }



    }
}
