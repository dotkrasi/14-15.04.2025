﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2.Data.Models
{
    public class Items
    {
        [Key]
        public int item_id { get; set; }

        [Required]
        [StringLength(50)]
        public string item_name { get; set; }

        [ForeignKey(nameof(Item_types))]
        public int item_type_id { get; set; }
        Item_types item_Types { get; set; }
    }
}
