﻿using ConsoleApp1.Controllers;
using ConsoleApp1.Presentation;
using ConsoleApp1.Data;

public class Program
{
    public static void Main(string[] args)
    {
        var context = new UniDbContext();

        var universityController = new UniversityController(context);
        var facultyController = new FacultyController(context);
        var majorController = new MajorController(context);

        var display = new Display(universityController, facultyController, majorController);
        display.ShowMenu();
    }
}