﻿using ConsoleApp1.Data;
using ConsoleApp1.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controllers
{
    public class MajorController
    {
        public UniDbContext UniDbContext { get; set; }

        public MajorController(UniDbContext uniDbContext)
        {
            this.UniDbContext = uniDbContext;
        }

        public async Task AddMajor(string name, int facultyId)
        {
            Major major = new Major()
            {
                MajorName = name,
                FacultyId = facultyId
            };
            UniDbContext.Major.Add(major);
            await UniDbContext.SaveChangesAsync();
            return;
        }

        public async Task<List<Major>> GetMajorsByFacultyId(int facultyId)
        {
            List<Major> major = await UniDbContext.Major
                .Where(m => m.FacultyId == facultyId)
                .Include(m => m.Faculty)
                .ToListAsync();
            return major;
        }

        public async Task<List<Major>> GetMajorsByName(string name)
        {
            List<Major> major = await UniDbContext.Major
                .Where(m => m.MajorName.Contains(name))
                .Include(m => m.Faculty)
                .ToListAsync();
            return major;
        }

        public Major? GetMajorByNameAndFacultyId(string name, int facultyId)
        {
            return UniDbContext.Major
                .Include(m => m.Faculty)
                .FirstOrDefault(m => m.MajorName == name && m.FacultyId == facultyId);
        }
    }
}
