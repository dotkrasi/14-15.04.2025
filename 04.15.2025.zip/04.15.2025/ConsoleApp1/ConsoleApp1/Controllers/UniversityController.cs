﻿using ConsoleApp1.Data;
using ConsoleApp1.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controllers
{
    public class UniversityController
    {
        public UniDbContext UniDbContext { get; set; }

        public UniversityController(UniDbContext uniDbContext)
        {
            this.UniDbContext = uniDbContext;
        }

        public async Task AddUniversity(string name)
        {
            Uni uni = new Uni()
            {
                Name = name
            };
            UniDbContext.Uni.Add(uni);
            await UniDbContext.SaveChangesAsync();
            return;
        }

        public async Task<List<Uni>> GetAllUniversities()
        {
            List<Uni> universities = UniDbContext.Uni.Include(u => u.Faculty).ToList();
            
            return universities;
        }

        public async Task<Uni?> GetUniversityByName(string name)
        {
            Uni uni = await UniDbContext.Uni.Where(m => m.Name == name)
                .Include(f => f.Faculty)
                .FirstOrDefaultAsync();
            return uni;
        }

        public async Task<int?> GetUniversityIdByName(string name)
        {
            Uni university = await UniDbContext.Uni.Where(u => u.Name == name).FirstOrDefaultAsync();
            return university?.Id;
        }
    }
}
