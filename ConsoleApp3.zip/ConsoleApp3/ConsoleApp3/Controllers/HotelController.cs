﻿using ConsoleApp3.Data;
using ConsoleApp3.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3.Controllers
{
    public class HotelController
    {

        public HotelManagerContext hotelManagerContext { get; set; }

        public HotelController(HotelManagerContext hotelManager)
        {
            this.hotelManagerContext = hotelManager;
        }


        public void AddGuest()
        {
            Guest guest = new Guest();

            hotelManagerContext.Guests.Add(guest);
            hotelManagerContext.SaveChanges();
        }

        public void ListGuests()
        {
            Guest guest = new Guest();
            hotelManagerContext.Guests.Add(guest);
            hotelManagerContext.SaveChanges();
            Console.WriteLine($"ID: {guest.Id}, Name: {guest.FirstName} {guest.LastName}, UCN: {guest.Ucn}, Phone: {guest.PhoneNumber}");

        }

    }
}
