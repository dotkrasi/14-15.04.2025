﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Data.Models
{
    public class Faculty
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public Uni University { get; set; }

        public int UniveristyId { get; set; }

        public List<Major> Major { get; set; } = new List<Major>();
        //       public int majorId { get; set; }
    }
}
