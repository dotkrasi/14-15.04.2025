﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Data.Models
{
    public class Major
    {
        [Key]
        public int MajorId { get; set; }

        [Required]
        public string MajorName { get; set; }

        [Required]
        public Faculty Faculty { get; set; }
        public int FacultyId { get; set; }

    }
}
