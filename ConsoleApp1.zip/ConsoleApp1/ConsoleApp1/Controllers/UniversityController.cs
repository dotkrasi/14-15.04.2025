﻿using ConsoleApp1.Data;
using ConsoleApp1.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controllers
{
    public class UniversityController
    {
        public UniDbContext UniDbContext { get; set; }

        public UniversityController(UniDbContext uniDbContext)
        {
            this.UniDbContext = uniDbContext;
        }

        public async Task AddUniversity(string name)
        {
            Uni uni = new Uni()
            {
                Name = name
            };

            UniDbContext.SaveChanges();
        }

        public List<Uni> GetAllUniversities()
        {
            return UniDbContext.Uni.Include(u => u.Faculty).ToList();
        }

        public Uni? GetUniversityByName(string name)
        {
            return UniDbContext.Uni.Where(m => m.Name == name)
                .Include(f => f.Faculty)
                .FirstOrDefault();
        }

        public int? GetUniversityIdByName(string name)
        {
            Uni university = UniDbContext.Uni.Where(u => u.Name == name).FirstOrDefault();
            return university?.Id;
        }
    }
}
