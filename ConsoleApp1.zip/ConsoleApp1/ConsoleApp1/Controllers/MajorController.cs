﻿using ConsoleApp1.Data;
using ConsoleApp1.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controllers
{
    public class MajorController
    {
        public UniDbContext UniDbContext { get; set; }

        public MajorController(UniDbContext uniDbContext)
        {
            this.UniDbContext = uniDbContext;
        }

        public void AddMajor(string name, int facultyId)
        {
            Major major = new Major();
            major.MajorName = name;
            major.FacultyId = facultyId;



            UniDbContext.Major.Add(major);
        }

        public List<Major> GetMajorsByFacultyId(int facultyId)
        {
            return UniDbContext.Major
                .Where(m => m.FacultyId == facultyId)
                .Include(m => m.Faculty)
                .ToList();
        }

        public List<Major> GetMajorsByName(string name)
        {
            return UniDbContext.Major
                .Where(m => m.MajorName.Contains(name))
                .Include(m => m.Faculty)
                .ToList();
        }

        public Major? GetMajorByNameAndFacultyId(string name, int facultyId)
        {
            return UniDbContext.Major
                .Include(m => m.Faculty)
                .FirstOrDefault(m => m.MajorName == name && m.FacultyId == facultyId);
        }
    }
}
