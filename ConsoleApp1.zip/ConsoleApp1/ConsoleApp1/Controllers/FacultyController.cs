﻿using ConsoleApp1.Data;
using ConsoleApp1.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controllers
{
    public class FacultyController
    {
        public UniDbContext UniDbContext { get; set; }

        public FacultyController(UniDbContext uniDbContext)
        {
            this.UniDbContext = uniDbContext;
        }

        public void AddFaculty(string name, int universityId)
        {
            Faculty faculty = new Faculty();
            faculty.Name = name;
            faculty.UniveristyId = universityId;

            UniDbContext.Faculty.Add(faculty);
        }

        public List<Faculty> GetFacultiesByUniversityId(int universityId)
        {
            return UniDbContext.Faculty
                .Where(n => n.UniveristyId == universityId)
                .Include(m => m.University)
                .ToList();
        }

        public List<Faculty> GetFacultiesByName(string name)
        {
            return UniDbContext.Faculty
                .Where(m => m.Name.Contains(name))
                .Include(m => m.University)
                .ToList();
        }

        public Faculty? GetFacultyByNameAndUniversityId(string name, int universityId)
        {
            return UniDbContext.Faculty
                    .Include(m => m.University)
                    .FirstOrDefault(m => m.Name == name && m.Id == universityId);
        }
    }
}
