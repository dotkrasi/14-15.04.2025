﻿using ConsoleApp1.Controllers;
using ConsoleApp1.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Presentation
{
    public class Display
    {

        public UniversityController _universityController;
        public FacultyController _facultyController;
        public MajorController _majorController;

        public Display(UniversityController universityController, FacultyController facultyController, MajorController majorController)
        {
            _universityController = universityController;
            _facultyController = facultyController;
            _majorController = majorController;
        }
        public void ShowMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("\n--- Main Menu ---");
                Console.WriteLine("1. Add university");
                Console.WriteLine("2. Add faculty");
                Console.WriteLine("3. Add major");
                Console.WriteLine("4. Show all universities");
                Console.WriteLine("5. Show faculties by university ID");
                Console.WriteLine("6. Show majors by faculty ID");
                Console.WriteLine("7. Show university ID by name");
                Console.WriteLine("8. Show faculty ID and name by name");
                Console.WriteLine("9. Show major ID and name by name");
                Console.WriteLine("10. Exit");
                Console.Write("Choose an option: ");

                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        AddUniversity();
                        break;
                    case "2":
                        AddFaculty();
                        break;
                    case "3":
                        AddMajor();
                        break;
                    case "4":
                        ShowAllUniversities();
                        break;
                    case "5":
                        ShowFacultiesByUniversityId();
                        break;
                    case "6":
                        ShowMajorsByFacultyId();
                        break;
                    case "7":
                        ShowUniversityIdByName();
                        break;
                    case "8":
                        ShowFacultyIdAndNameByName();
                        break;
                    case "9":
                        ShowMajorIdAndNameByName();
                        break;
                    case "10":
                        Console.WriteLine("Exiting...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }
        private void AddUniversity()
        {
            Console.Clear();
            Console.Write("Enter university name: ");
            string name = Console.ReadLine();

            _universityController.AddUniversity(name);
            Console.WriteLine("University added.");
        }

        private void AddFaculty()
        {
            Console.Clear();

            Console.Write("Enter faculty name: ");
            string name = Console.ReadLine();
            Console.Write("Enter university ID: ");
            if (int.TryParse(Console.ReadLine(), out int uniId))
            {
                _facultyController.AddFaculty(name, uniId);
                Console.WriteLine("Faculty added.");
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }
        }

        private void AddMajor()
        {
            Console.Clear();

            Console.Write("Enter major name: ");
            string name = Console.ReadLine();
            Console.Write("Enter faculty ID: ");
            if (int.TryParse(Console.ReadLine(), out int facultyId))
            {
                _majorController.AddMajor(name, facultyId);
                Console.WriteLine("Major added.");
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }
        }

        private void ShowAllUniversities()
        {
            Console.Clear();

            var unis = _universityController.GetAllUniversities();
            foreach (var uni in unis)
            {
                Console.WriteLine($"ID: {uni.Id}, Name: {uni.Name}");
            }
        }

        private void ShowFacultiesByUniversityId()
        {
            Console.Clear();

            Console.Write("Enter university ID: ");
            if (int.TryParse(Console.ReadLine(), out int uniId))
            {
                var faculties = _facultyController.GetFacultiesByUniversityId(uniId);
                foreach (var fac in faculties)
                {
                    Console.WriteLine($"ID: {fac.Id}, Name: {fac.Name}");
                }
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }
        }

        private void ShowMajorsByFacultyId()
        {
            Console.Clear();

            Console.Write("Enter faculty ID: ");
            if (int.TryParse(Console.ReadLine(), out int facultyId))
            {
                var majors = _majorController.GetMajorsByFacultyId(facultyId);
                foreach (var major in majors)
                {
                    Console.WriteLine($"ID: {major.MajorId}, Name: {major.MajorName}");
                }
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }
        }

        private void ShowUniversityIdByName()
        {
            Console.Clear();

            Console.Write("Enter university name: ");
            string name = Console.ReadLine();

            int? id = _universityController.GetUniversityIdByName(name);
            Console.WriteLine(id.HasValue ? $"University ID: {id}" : "University not found.");
        }

        private void ShowFacultyIdAndNameByName()
        {
            Console.Clear();

            Console.Write("Enter faculty name: ");
            string name = Console.ReadLine();

            List<Faculty> faculties = _facultyController.GetFacultiesByName(name);

            if (faculties == null || faculties.Count == 0)
            {
                Console.WriteLine("No faculties found with that name.");
                return;
            }

            foreach (Faculty faculty in faculties)
            {
                Console.WriteLine($"Faculty ID: {faculty.Id}, Name: {faculty.Name}");
            }
        }

        private void ShowMajorIdAndNameByName()
        {
            Console.Clear();

            Console.Write("Enter major name: ");
            string name = Console.ReadLine();

            var majors = _majorController.GetMajorsByName(name);
            if (majors.Count == 0)
            {
                Console.WriteLine("No majors found.");
                return;
            }

            foreach (var major in majors)
            {
                Console.WriteLine($"Major ID: {major.MajorId}, Name: {major.MajorName}");
            }
        }
    }
}
